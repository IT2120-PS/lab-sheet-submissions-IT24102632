setwd("C:\\Users\\IT24102632\\Desktop\\IT24102632")

Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)
attach(Delivery_Times)

#Q2
names(Delivery_Times)<-c("X1")
histogram<-hist(X1,main="Histogram for number of Shareholders",breaks = seq(20, 70,length = 9),right = TRUE)

#Q3
install.packages("e1071")
library(e1071)

skewness(Delivery_Times$Delivery_Time)

#pt4
breaks = round(histogram$breaks)
freq = histogram$counts
mids = histogram$mids
classes = c()

for (i in 1:length(breaks)-1) {
  classes[i] <- paste0("[", breaks[i], ",", breaks[i+1], ")")
}

cbind(classes = classes, Frequency = freq)


cum.freq <- cumsum(freq)
new <- c()

for(i in 1:length(breaks)){
  if(i==1){
    new[i] = 0
  }else{
    new[i] = cum.freq[i-1]
  }
}

plot(breaks, new, type = "l", main = "Cumalative Frequancy polygon for deliver times",xlab = "deliver times", ylab = "Frequancy", ylim = c(0,max(cum.freq)))                  
cbind(Upper = breaks, CumFreq = new)