# Set working directory (replace with your path)
setwd("C:\\Users\\User\\OneDrive\\Desktop\\IT24102632")  

# i. Generate a random sample of size 25 for the baking time
set.seed(42)
baking_times <- rnorm(25, mean = 45, sd = 2)
baking_times

# ii. Test whether the average baking time is less than 46 minutes at 5% level of significance
test_result <- t.test(baking_times, mu = 46, alternative = "less")
test_result