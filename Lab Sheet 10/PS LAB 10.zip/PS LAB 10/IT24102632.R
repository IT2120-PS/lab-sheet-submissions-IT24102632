setwd("C:\\Users\\User\\Downloads\\PS LAB 10")

observed <- c(120, 95, 85, 100)
chisq.test(observed)