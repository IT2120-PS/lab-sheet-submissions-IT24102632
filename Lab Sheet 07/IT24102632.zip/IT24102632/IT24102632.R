setwd("C:\\Users\\User\\OneDrive\\Desktop\\IT24102632")

#EXERCISE
#Ex.1
punif(25,min = 0, max = 40) - punif(10, min = 0, max = 40)

#Ex.2
pexp(2, rate = 1/3)

#Ex.3.1
pnorm(130, mean = 100, sd = 15)

#Ex.3.2
qnorm(0.95, mean = 100, sd = 15)

